elements= [9,55,90,47,8,0]
print("The list:",elements)
elements.sort(reverse=True)  
print("The third largest element is : ",elements[2])