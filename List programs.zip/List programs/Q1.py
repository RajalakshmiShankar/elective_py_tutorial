num = [3, 1, 7, 9, 2, 8]
print("The list:",num)
largest = max(num)
smallest = min(num)

print("Largest number:", largest)
print("Smallest number:", smallest)
